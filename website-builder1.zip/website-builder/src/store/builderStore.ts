import { create } from 'zustand'
import { Block, BlockType, DeviceMode } from '../types'
import { BLOCK_DEFINITIONS } from '../blocks/definitions'

interface BuilderState {
  blocks: Block[]
  selectedId: string | null
  device: DeviceMode
  // Actions
  addBlock: (type: BlockType, atIndex?: number) => void
  removeBlock: (id: string) => void
  moveBlock: (id: string, direction: -1 | 1) => void
  selectBlock: (id: string | null) => void
  updateProp: (id: string, key: string, value: string | number | boolean) => void
  setDevice: (device: DeviceMode) => void
  clearCanvas: () => void
}

let nextId = 1

export const useBuilderStore = create<BuilderState>((set, get) => ({
  blocks: [],
  selectedId: null,
  device: 'desktop',

  addBlock: (type, atIndex) => {
    const def = BLOCK_DEFINITIONS[type]
    const block: Block = {
      id: `block_${nextId++}`,
      type,
      props: { ...def.defaultProps },
    }
    set((state) => {
      const blocks = [...state.blocks]
      if (atIndex !== undefined) {
        blocks.splice(atIndex, 0, block)
      } else {
        blocks.push(block)
      }
      return { blocks, selectedId: block.id }
    })
  },

  removeBlock: (id) => {
    set((state) => ({
      blocks: state.blocks.filter((b) => b.id !== id),
      selectedId: state.selectedId === id ? null : state.selectedId,
    }))
  },

  moveBlock: (id, direction) => {
    set((state) => {
      const blocks = [...state.blocks]
      const i = blocks.findIndex((b) => b.id === id)
      const j = i + direction
      if (j < 0 || j >= blocks.length) return state
      ;[blocks[i], blocks[j]] = [blocks[j], blocks[i]]
      return { blocks }
    })
  },

  selectBlock: (id) => set({ selectedId: id }),

  updateProp: (id, key, value) => {
    set((state) => ({
      blocks: state.blocks.map((b) =>
        b.id === id ? { ...b, props: { ...b.props, [key]: value } } : b
      ),
    }))
  },

  setDevice: (device) => set({ device }),

  clearCanvas: () => set({ blocks: [], selectedId: null }),
}))
