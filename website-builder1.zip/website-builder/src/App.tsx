import React from 'react'
import { LeftPanel } from './components/LeftPanel'
import { Canvas } from './components/Canvas'
import { RightPanel } from './components/RightPanel'
import './styles.css'

export default function App() {
  return (
    <div className="app">
      <LeftPanel />
      <Canvas />
      <RightPanel />
    </div>
  )
}
