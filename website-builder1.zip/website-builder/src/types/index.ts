export type BlockType =
  | 'hero'
  | 'text'
  | 'image'
  | 'button'
  | 'columns'
  | 'card'
  | 'divider'
  | 'footer'
  | 'navbar'

export interface BlockProps {
  [key: string]: string | number | boolean
}

export interface Block {
  id: string
  type: BlockType
  props: BlockProps
}

export type DeviceMode = 'desktop' | 'tablet' | 'mobile'

export interface BlockDefinition {
  label: string
  icon: string
  category: 'layout' | 'content' | 'media'
  defaultProps: BlockProps
  propSchema: PropSchema[]
}

export interface PropSchema {
  key: string
  label: string
  type: 'text' | 'textarea' | 'color' | 'number' | 'select'
  options?: string[]
}
