import { BlockDefinition, BlockType } from '../types'

export const BLOCK_DEFINITIONS: Record<BlockType, BlockDefinition> = {
  navbar: {
    label: 'Navbar',
    icon: 'ti-layout-navbar',
    category: 'layout',
    defaultProps: { brand: 'My Site', links: 'Home, About, Contact', bg: '#ffffff', color: '#1a1a1a' },
    propSchema: [
      { key: 'brand', label: 'Brand name', type: 'text' },
      { key: 'links', label: 'Links (comma separated)', type: 'text' },
      { key: 'bg', label: 'Background', type: 'color' },
      { key: 'color', label: 'Text color', type: 'color' },
    ],
  },
  hero: {
    label: 'Hero',
    icon: 'ti-layout-distribute-vertical',
    category: 'layout',
    defaultProps: {
      title: 'Build something amazing',
      subtitle: 'A beautiful website starts here.',
      ctaLabel: 'Get started',
      bg: '#EAF3DE',
      color: '#173404',
      align: 'center',
    },
    propSchema: [
      { key: 'title', label: 'Heading', type: 'text' },
      { key: 'subtitle', label: 'Subtitle', type: 'textarea' },
      { key: 'ctaLabel', label: 'CTA label', type: 'text' },
      { key: 'bg', label: 'Background', type: 'color' },
      { key: 'color', label: 'Text color', type: 'color' },
      { key: 'align', label: 'Alignment', type: 'select', options: ['left', 'center', 'right'] },
    ],
  },
  text: {
    label: 'Text',
    icon: 'ti-text-size',
    category: 'content',
    defaultProps: {
      content: 'Nhập nội dung của bạn vào đây. Đây là đoạn văn bản mẫu dùng để trình bày nội dung.',
      fontSize: '15',
      color: '#333333',
      align: 'left',
    },
    propSchema: [
      { key: 'content', label: 'Content', type: 'textarea' },
      { key: 'fontSize', label: 'Font size (px)', type: 'number' },
      { key: 'color', label: 'Color', type: 'color' },
      { key: 'align', label: 'Alignment', type: 'select', options: ['left', 'center', 'right'] },
    ],
  },
  image: {
    label: 'Image',
    icon: 'ti-photo',
    category: 'media',
    defaultProps: { src: '', alt: 'Image', height: '200', objectFit: 'cover' },
    propSchema: [
      { key: 'src', label: 'Image URL', type: 'text' },
      { key: 'alt', label: 'Alt text', type: 'text' },
      { key: 'height', label: 'Height (px)', type: 'number' },
      { key: 'objectFit', label: 'Fit', type: 'select', options: ['cover', 'contain', 'fill'] },
    ],
  },
  button: {
    label: 'Button',
    icon: 'ti-cursor-text',
    category: 'content',
    defaultProps: { label: 'Click here', align: 'center', bg: '#639922', color: '#ffffff', size: 'medium' },
    propSchema: [
      { key: 'label', label: 'Label', type: 'text' },
      { key: 'bg', label: 'Background', type: 'color' },
      { key: 'color', label: 'Text color', type: 'color' },
      { key: 'align', label: 'Align', type: 'select', options: ['left', 'center', 'right'] },
      { key: 'size', label: 'Size', type: 'select', options: ['small', 'medium', 'large'] },
    ],
  },
  columns: {
    label: '2 Columns',
    icon: 'ti-columns',
    category: 'layout',
    defaultProps: { left: 'Nội dung cột trái', right: 'Nội dung cột phải', gap: '16' },
    propSchema: [
      { key: 'left', label: 'Left content', type: 'textarea' },
      { key: 'right', label: 'Right content', type: 'textarea' },
      { key: 'gap', label: 'Gap (px)', type: 'number' },
    ],
  },
  card: {
    label: 'Feature card',
    icon: 'ti-layout-cards',
    category: 'content',
    defaultProps: { title: 'Feature title', desc: 'Mô tả tính năng của bạn ở đây.', icon: 'ti-star', iconColor: '#639922' },
    propSchema: [
      { key: 'title', label: 'Title', type: 'text' },
      { key: 'desc', label: 'Description', type: 'textarea' },
      { key: 'icon', label: 'Icon class (ti-*)', type: 'text' },
      { key: 'iconColor', label: 'Icon color', type: 'color' },
    ],
  },
  divider: {
    label: 'Divider',
    icon: 'ti-separator',
    category: 'layout',
    defaultProps: { spacing: '16', color: '#e0e0e0' },
    propSchema: [
      { key: 'spacing', label: 'Spacing (px)', type: 'number' },
      { key: 'color', label: 'Color', type: 'color' },
    ],
  },
  footer: {
    label: 'Footer',
    icon: 'ti-layout-bottombar',
    category: 'layout',
    defaultProps: { text: '© 2025 My Website. All rights reserved.', bg: '#2C2C2A', color: '#D3D1C7' },
    propSchema: [
      { key: 'text', label: 'Text', type: 'text' },
      { key: 'bg', label: 'Background', type: 'color' },
      { key: 'color', label: 'Text color', type: 'color' },
    ],
  },
}

export const BLOCK_CATEGORIES = {
  layout: { label: 'Layout', blocks: ['navbar', 'hero', 'columns', 'divider', 'footer'] },
  content: { label: 'Content', blocks: ['text', 'button', 'card'] },
  media: { label: 'Media', blocks: ['image'] },
} as const
