import React from 'react'
import { Block } from '../types'

interface BlockRendererProps {
  block: Block
}

export function BlockRenderer({ block }: BlockRendererProps) {
  const p = block.props

  switch (block.type) {
    case 'navbar':
      return (
        <div style={{ background: p.bg as string, padding: '14px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #e5e5e5' }}>
          <span style={{ fontWeight: 600, fontSize: 16, color: p.color as string }}>{p.brand as string}</span>
          <div style={{ display: 'flex', gap: 20 }}>
            {String(p.links).split(',').map((link, i) => (
              <a key={i} style={{ fontSize: 14, color: p.color as string, textDecoration: 'none', opacity: 0.8 }}>{link.trim()}</a>
            ))}
          </div>
        </div>
      )

    case 'hero':
      return (
        <div style={{ background: p.bg as string, padding: '64px 32px', textAlign: p.align as any }}>
          <h1 style={{ fontSize: 36, fontWeight: 700, color: p.color as string, marginBottom: 16, lineHeight: 1.2 }}>{p.title as string}</h1>
          <p style={{ fontSize: 16, color: p.color as string, opacity: 0.75, marginBottom: 28, lineHeight: 1.6, maxWidth: 560, margin: '0 auto 28px' }}>{p.subtitle as string}</p>
          {p.ctaLabel && (
            <button style={{ background: p.color as string, color: p.bg as string, border: 'none', padding: '12px 28px', borderRadius: 8, fontSize: 15, fontWeight: 600, cursor: 'pointer' }}>
              {p.ctaLabel as string}
            </button>
          )}
        </div>
      )

    case 'text':
      return (
        <div style={{ padding: '16px 24px' }}>
          <p style={{ fontSize: Number(p.fontSize) || 15, color: p.color as string, lineHeight: 1.7, textAlign: p.align as any, margin: 0 }}>
            {p.content as string}
          </p>
        </div>
      )

    case 'image':
      return (
        <div style={{ width: '100%', height: Number(p.height) || 200, overflow: 'hidden', background: '#f0f0f0' }}>
          {p.src ? (
            <img src={p.src as string} alt={p.alt as string} style={{ width: '100%', height: '100%', objectFit: (p.objectFit as any) || 'cover' }} />
          ) : (
            <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 8, color: '#aaa' }}>
              <i className="ti ti-photo" style={{ fontSize: 36 }} />
              <span style={{ fontSize: 13 }}>{p.alt as string}</span>
            </div>
          )}
        </div>
      )

    case 'button': {
      const sizeMap = { small: '8px 18px', medium: '12px 28px', large: '16px 40px' }
      const sizeKey = (p.size as string) || 'medium'
      return (
        <div style={{ padding: '16px 24px', textAlign: p.align as any }}>
          <button style={{ background: p.bg as string, color: p.color as string, border: 'none', padding: sizeMap[sizeKey as keyof typeof sizeMap], borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
            {p.label as string}
          </button>
        </div>
      )
    }

    case 'columns':
      return (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: Number(p.gap) || 16, padding: '16px 24px' }}>
          <div style={{ background: '#f8f8f8', borderRadius: 8, padding: 16, fontSize: 14, color: '#555', lineHeight: 1.6 }}>{p.left as string}</div>
          <div style={{ background: '#f8f8f8', borderRadius: 8, padding: 16, fontSize: 14, color: '#555', lineHeight: 1.6 }}>{p.right as string}</div>
        </div>
      )

    case 'card':
      return (
        <div style={{ padding: '20px 24px', display: 'flex', gap: 16, alignItems: 'flex-start' }}>
          <i className={`ti ${p.icon as string}`} style={{ fontSize: 32, color: p.iconColor as string, flexShrink: 0, marginTop: 2 }} />
          <div>
            <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 6 }}>{p.title as string}</div>
            <div style={{ fontSize: 14, color: '#666', lineHeight: 1.6 }}>{p.desc as string}</div>
          </div>
        </div>
      )

    case 'divider':
      return (
        <div style={{ padding: `${Number(p.spacing) || 16}px 24px` }}>
          <hr style={{ border: 'none', borderTop: `1px solid ${p.color as string}`, margin: 0 }} />
        </div>
      )

    case 'footer':
      return (
        <div style={{ background: p.bg as string, padding: '24px', textAlign: 'center', fontSize: 13, color: p.color as string }}>
          {p.text as string}
        </div>
      )

    default:
      return <div style={{ padding: 16, color: '#999', fontSize: 13 }}>Unknown block type</div>
  }
}
