import React, { useState } from 'react'
import { BlockType } from '../../types'
import { BLOCK_DEFINITIONS, BLOCK_CATEGORIES } from '../../blocks/definitions'
import { useBuilderStore } from '../../store/builderStore'

export function LeftPanel() {
  const [search, setSearch] = useState('')
  const addBlock = useBuilderStore((s) => s.addBlock)

  const filteredCategories = Object.entries(BLOCK_CATEGORIES).map(([catKey, cat]) => ({
    ...cat,
    key: catKey,
    blocks: cat.blocks.filter((type) =>
      BLOCK_DEFINITIONS[type as BlockType].label.toLowerCase().includes(search.toLowerCase())
    ),
  }))

  const handleDragStart = (e: React.DragEvent, type: BlockType) => {
    e.dataTransfer.setData('blockType', type)
    e.dataTransfer.effectAllowed = 'copy'
  }

  return (
    <aside className="left-panel">
      <div className="panel-header">
        <span>Components</span>
      </div>

      <div className="panel-search">
        <i className="ti ti-search" />
        <input
          type="text"
          placeholder="Search..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="block-list">
        {filteredCategories.map((cat) =>
          cat.blocks.length > 0 ? (
            <div key={cat.key} className="block-category">
              <div className="category-label">{cat.label}</div>
              {cat.blocks.map((type) => {
                const def = BLOCK_DEFINITIONS[type as BlockType]
                return (
                  <div
                    key={type}
                    className="block-item"
                    draggable
                    onDragStart={(e) => handleDragStart(e, type as BlockType)}
                    onClick={() => addBlock(type as BlockType)}
                    title={`Add ${def.label}`}
                  >
                    <i className={`ti ${def.icon}`} />
                    <span>{def.label}</span>
                    <i className="ti ti-plus add-icon" />
                  </div>
                )
              })}
            </div>
          ) : null
        )}
      </div>
    </aside>
  )
}
