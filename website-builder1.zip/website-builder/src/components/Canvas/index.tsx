import React, { useState } from 'react'
import { useBuilderStore } from '../../store/builderStore'
import { BlockRenderer } from '../../blocks/BlockRenderer'
import { BlockType, DeviceMode } from '../../types'

const DEVICE_WIDTHS: Record<DeviceMode, string> = {
  desktop: '100%',
  tablet: '768px',
  mobile: '375px',
}

export function Canvas() {
  const { blocks, selectedId, device, addBlock, removeBlock, moveBlock, selectBlock, setDevice, clearCanvas } = useBuilderStore()
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null)
  const [isDragOver, setIsDragOver] = useState(false)

  const handleDrop = (e: React.DragEvent, index?: number) => {
    e.preventDefault()
    e.stopPropagation()
    setDragOverIndex(null)
    setIsDragOver(false)
    const type = e.dataTransfer.getData('blockType') as BlockType
    if (type) addBlock(type, index)
  }

  const handleDragOver = (e: React.DragEvent, index?: number) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = 'copy'
    if (index !== undefined) setDragOverIndex(index)
    else setIsDragOver(true)
  }

  return (
    <div className="canvas-area">
      {/* Toolbar */}
      <div className="toolbar">
        <span className="site-name">
          <i className="ti ti-layout" />
          My Website
        </span>

        <div className="device-switcher">
          {(['desktop', 'tablet', 'mobile'] as DeviceMode[]).map((d) => (
            <button
              key={d}
              className={`device-btn ${device === d ? 'active' : ''}`}
              onClick={() => setDevice(d)}
              title={d}
            >
              <i className={`ti ti-device-${d}`} />
            </button>
          ))}
        </div>

        <div className="toolbar-actions">
          <button className="toolbar-btn" onClick={clearCanvas} title="Clear canvas">
            <i className="ti ti-trash" /> Clear
          </button>
          <button className="toolbar-btn primary" title="Export">
            <i className="ti ti-download" /> Export
          </button>
        </div>
      </div>

      {/* Canvas */}
      <div className="canvas-scroll">
        <div
          className="canvas-inner"
          style={{ maxWidth: DEVICE_WIDTHS[device] }}
          onClick={(e) => {
            if ((e.target as HTMLElement).classList.contains('canvas-inner')) {
              selectBlock(null)
            }
          }}
        >
          {blocks.length === 0 ? (
            <div
              className={`empty-canvas ${isDragOver ? 'drag-over' : ''}`}
              onDrop={(e) => handleDrop(e)}
              onDragOver={(e) => handleDragOver(e)}
              onDragLeave={() => setIsDragOver(false)}
            >
              <i className="ti ti-layout-grid-add" />
              <p>Kéo component từ panel trái vào đây</p>
              <small>Hoặc click vào component để thêm</small>
            </div>
          ) : (
            <>
              {blocks.map((block, index) => (
                <React.Fragment key={block.id}>
                  {/* Drop zone between blocks */}
                  <div
                    className={`drop-between ${dragOverIndex === index ? 'active' : ''}`}
                    onDrop={(e) => handleDrop(e, index)}
                    onDragOver={(e) => handleDragOver(e, index)}
                    onDragLeave={() => setDragOverIndex(null)}
                  />

                  <div
                    className={`canvas-block ${selectedId === block.id ? 'selected' : ''}`}
                    onClick={() => selectBlock(block.id)}
                  >
                    {/* Block label */}
                    <div className="block-label">
                      <i className={`ti ${useBuilderStore.getState().blocks.find(b => b.id === block.id) ? 'ti-grip-vertical' : ''}`} />
                      {block.type}
                    </div>

                    {/* Block content */}
                    <BlockRenderer block={block} />

                    {/* Block actions */}
                    <div className="block-actions">
                      <button
                        className="action-btn"
                        onClick={(e) => { e.stopPropagation(); moveBlock(block.id, -1) }}
                        disabled={index === 0}
                        title="Move up"
                      >
                        <i className="ti ti-arrow-up" />
                      </button>
                      <button
                        className="action-btn"
                        onClick={(e) => { e.stopPropagation(); moveBlock(block.id, 1) }}
                        disabled={index === blocks.length - 1}
                        title="Move down"
                      >
                        <i className="ti ti-arrow-down" />
                      </button>
                      <button
                        className="action-btn danger"
                        onClick={(e) => { e.stopPropagation(); removeBlock(block.id) }}
                        title="Delete"
                      >
                        <i className="ti ti-trash" />
                      </button>
                    </div>
                  </div>
                </React.Fragment>
              ))}

              {/* Drop zone at end */}
              <div
                className={`drop-between ${dragOverIndex === blocks.length ? 'active' : ''}`}
                onDrop={(e) => handleDrop(e, blocks.length)}
                onDragOver={(e) => handleDragOver(e, blocks.length)}
                onDragLeave={() => setDragOverIndex(null)}
              />
            </>
          )}
        </div>
      </div>
    </div>
  )
}
