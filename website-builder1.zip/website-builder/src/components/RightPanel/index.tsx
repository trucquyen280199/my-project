import React from 'react'
import { useBuilderStore } from '../../store/builderStore'
import { BLOCK_DEFINITIONS } from '../../blocks/definitions'

export function RightPanel() {
  const { blocks, selectedId, updateProp } = useBuilderStore()
  const selectedBlock = blocks.find((b) => b.id === selectedId)

  if (!selectedBlock) {
    return (
      <aside className="right-panel">
        <div className="panel-header">Properties</div>
        <div className="no-selection">
          <i className="ti ti-hand-click" />
          <p>Chọn một block để chỉnh sửa</p>
        </div>
      </aside>
    )
  }

  const def = BLOCK_DEFINITIONS[selectedBlock.type]

  return (
    <aside className="right-panel">
      <div className="panel-header">
        <i className={`ti ${def.icon}`} />
        {def.label}
      </div>

      <div className="props-list">
        {def.propSchema.map((schema) => {
          const value = selectedBlock.props[schema.key] ?? ''

          return (
            <div key={schema.key} className="prop-row">
              <label className="prop-label">{schema.label}</label>

              {schema.type === 'text' && (
                <input
                  type="text"
                  className="prop-input"
                  value={value as string}
                  onChange={(e) => updateProp(selectedBlock.id, schema.key, e.target.value)}
                />
              )}

              {schema.type === 'textarea' && (
                <textarea
                  className="prop-input prop-textarea"
                  value={value as string}
                  rows={3}
                  onChange={(e) => updateProp(selectedBlock.id, schema.key, e.target.value)}
                />
              )}

              {schema.type === 'number' && (
                <input
                  type="number"
                  className="prop-input"
                  value={value as number}
                  onChange={(e) => updateProp(selectedBlock.id, schema.key, Number(e.target.value))}
                />
              )}

              {schema.type === 'color' && (
                <div className="color-row">
                  <input
                    type="color"
                    className="color-picker"
                    value={value as string}
                    onChange={(e) => updateProp(selectedBlock.id, schema.key, e.target.value)}
                  />
                  <input
                    type="text"
                    className="prop-input color-text"
                    value={value as string}
                    onChange={(e) => updateProp(selectedBlock.id, schema.key, e.target.value)}
                  />
                </div>
              )}

              {schema.type === 'select' && (
                <select
                  className="prop-input prop-select"
                  value={value as string}
                  onChange={(e) => updateProp(selectedBlock.id, schema.key, e.target.value)}
                >
                  {schema.options?.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              )}
            </div>
          )
        })}
      </div>
    </aside>
  )
}
