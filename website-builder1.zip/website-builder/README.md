# Website Builder

Drag-and-drop website builder built with React + TypeScript + Zustand.

## Quick start

```bash
npm install
npm run dev
```

Open http://localhost:5173

## Stack

- **React 18** + **TypeScript**
- **Zustand** — lightweight state management
- **Vite** — fast dev server & bundler
- **Tabler Icons** — icon webfont

## Project structure

```
src/
├── blocks/
│   ├── definitions.ts      # Block registry (types, props schema, defaults)
│   └── BlockRenderer.tsx   # Renders each block type
├── components/
│   ├── LeftPanel/          # Component list with drag support
│   ├── Canvas/             # Drop zone + block management
│   └── RightPanel/         # Properties editor
├── store/
│   └── builderStore.ts     # Zustand state (blocks, selection, device)
├── types/
│   └── index.ts            # TypeScript types
├── styles.css              # Global styles
└── App.tsx
```

## Adding a new block type

1. Add type to `BlockType` union in `src/types/index.ts`
2. Add definition in `src/blocks/definitions.ts`
3. Add render case in `src/blocks/BlockRenderer.tsx`
4. Add to category in `BLOCK_CATEGORIES`

## Roadmap ideas

- [ ] Undo/redo (zustand middleware)
- [ ] Export to HTML/JSON
- [ ] Drag to reorder (dnd-kit)
- [ ] More block types (form, grid, video)
- [ ] Save/load projects (localStorage or API)
- [ ] Dark mode
- [ ] Custom fonts & global styles
